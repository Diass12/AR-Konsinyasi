AR KONSINYASI - CLOUD APK BUILD

Tujuan:
Build APK Android tanpa PC menggunakan GitHub Actions.

File yang diperlukan:
1. AR_Konsinyasi_Aplikasi_FINAL_V12.zip
2. .github/workflows/build-apk.yml

Langkah:
1. Buat repository GitHub baru.
2. Upload dua item di atas ke repository (ZIP dan folder .github/workflows/build-apk.yml).
3. Buka tab Actions.
4. Pilih workflow "Build AR Konsinyasi APK".
5. Tekan Run workflow.
6. Tunggu sampai status berhasil.
7. Buka hasil workflow dan bagian Artifacts.
8. Download "AR-Konsinyasi-V12-debug".
9. Extract ZIP artifact dan install app-debug.apk di Android.

Catatan:
- Build dilakukan di GitHub-hosted runner.
- Tidak membutuhkan PC lokal setelah file di-upload.
- APK debug ditujukan untuk pengujian/internal, bukan Play Store.
